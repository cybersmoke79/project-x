# NOTES:

1. Almost all the packages update to latest version.
2. react-dnd and react-dnd-html5-backend can't be updated becouse of react-tag-input required it.
