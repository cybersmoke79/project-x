# Mate Admin - React Redux Admin Dashboard. `v1.5`

### Please check `src/packages/settings/index.js` & edit as your app.
