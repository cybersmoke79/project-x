# Mate Admin - React Redux Admin Dashboard. `v1.4`

### Please check `src/settings/index.js` & edit as your app.
