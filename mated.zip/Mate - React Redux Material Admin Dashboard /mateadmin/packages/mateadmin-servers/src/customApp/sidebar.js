const options = [
  {
    label: "sidebar.blankPage",
    key: "blank-page"
  }
];
export default options;
