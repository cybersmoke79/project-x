import styled from 'styled-components';

const RenderColumnWrapper = styled.div`
  form {
    .MuiTextField-root {
      margin-bottom: 20px;
    }
  }
`;

export default RenderColumnWrapper;
