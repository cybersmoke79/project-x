import Rate from "react-star-rating-component";

export default Rate;
