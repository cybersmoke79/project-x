import Badge from '@material-ui/core/Badge';

export default Badge;
