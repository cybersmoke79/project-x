import Modal from '@material-ui/core/Modal';

export default Modal;
