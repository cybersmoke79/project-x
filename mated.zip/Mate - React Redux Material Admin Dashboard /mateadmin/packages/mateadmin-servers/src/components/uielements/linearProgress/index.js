import LinearProgress from '@material-ui/core/LinearProgress';

export default LinearProgress;
