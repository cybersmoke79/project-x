import Tooltip from '@material-ui/core/Tooltip';

export default Tooltip;
