import OutlinedInput from '@material-ui/core/OutlinedInput';

export default OutlinedInput;
