import NoSsr from '@material-ui/core/NoSsr';

export default NoSsr;
