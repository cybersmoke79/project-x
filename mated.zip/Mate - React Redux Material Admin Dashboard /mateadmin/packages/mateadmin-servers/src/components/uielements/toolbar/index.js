import Toolbar from '@material-ui/core/Toolbar';

export default Toolbar;
