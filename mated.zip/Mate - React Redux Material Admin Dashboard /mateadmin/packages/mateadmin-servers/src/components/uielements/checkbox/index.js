import Checkbox from '@material-ui/core/Checkbox';

export default Checkbox;
