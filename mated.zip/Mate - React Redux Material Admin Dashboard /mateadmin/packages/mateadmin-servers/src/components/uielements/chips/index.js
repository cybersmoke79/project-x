import Chip from '@material-ui/core/Chip';

export default Chip;
