import { ThemeProvider } from '@material-ui/styles';
export default ThemeProvider;
