import Fade from '@material-ui/core/Fade';

export default Fade;
