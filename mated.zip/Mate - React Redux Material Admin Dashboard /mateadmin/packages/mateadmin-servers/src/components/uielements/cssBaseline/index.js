import CssBaseline from '@material-ui/core/CssBaseline';

export default CssBaseline;
