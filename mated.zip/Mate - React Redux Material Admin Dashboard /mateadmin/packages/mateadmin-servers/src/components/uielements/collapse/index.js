import Collapse from '@material-ui/core/Collapse';

export default Collapse;
