import Pagination from "rc-pagination";

export default Pagination;
