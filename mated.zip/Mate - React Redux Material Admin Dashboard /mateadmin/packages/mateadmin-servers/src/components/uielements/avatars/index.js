import Avatar from '@material-ui/core/Avatar';

export default Avatar;
