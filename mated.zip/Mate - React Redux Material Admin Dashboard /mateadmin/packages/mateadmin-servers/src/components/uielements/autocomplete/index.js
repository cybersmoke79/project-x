import Autosuggest from "react-autosuggest";

export default Autosuggest;
