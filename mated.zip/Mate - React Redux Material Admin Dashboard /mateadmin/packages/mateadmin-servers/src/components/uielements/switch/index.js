import Switch from '@material-ui/core/Switch';

export default Switch;
