import CircularProgress from '@material-ui/core/CircularProgress';

export default CircularProgress;
