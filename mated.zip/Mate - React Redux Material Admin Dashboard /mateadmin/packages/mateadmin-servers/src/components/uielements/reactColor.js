import {
  SketchPicker,
  ChromePicker,
  SwatchesPicker,
  PhotoshopPicker,
  TwitterPicker,
  GithubPicker,
  BlockPicker,
  CirclePicker,
  CompactPicker
} from 'react-color';

export {
  SketchPicker,
  ChromePicker,
  SwatchesPicker,
  PhotoshopPicker,
  TwitterPicker,
  GithubPicker,
  BlockPicker,
  CirclePicker,
  CompactPicker
};
