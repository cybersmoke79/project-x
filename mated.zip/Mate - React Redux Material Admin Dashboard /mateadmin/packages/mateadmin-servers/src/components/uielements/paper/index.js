import Paper from '@material-ui/core/Paper';

export default Paper;
