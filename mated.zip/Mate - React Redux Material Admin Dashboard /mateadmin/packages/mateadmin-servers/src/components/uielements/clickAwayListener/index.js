import ClickAwayListener from '@material-ui/core/ClickAwayListener';

export default ClickAwayListener;
