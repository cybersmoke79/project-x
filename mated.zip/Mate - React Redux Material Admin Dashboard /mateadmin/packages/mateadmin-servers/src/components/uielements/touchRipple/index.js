import TouchRipple from '@material-ui/core/ButtonBase/TouchRipple';

export default TouchRipple;
