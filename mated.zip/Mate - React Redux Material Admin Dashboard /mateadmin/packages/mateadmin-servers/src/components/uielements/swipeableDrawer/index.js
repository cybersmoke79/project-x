import SwipeableDrawer from '@material-ui/core/SwipeableDrawer';

export default SwipeableDrawer;
