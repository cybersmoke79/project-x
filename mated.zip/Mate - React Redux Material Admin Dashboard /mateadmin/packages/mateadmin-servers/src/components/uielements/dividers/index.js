import Divider from '@material-ui/core/Divider';

export default Divider;
