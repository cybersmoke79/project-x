import { CopyToClipboard } from 'react-copy-to-clipboard';

export default CopyToClipboard;
