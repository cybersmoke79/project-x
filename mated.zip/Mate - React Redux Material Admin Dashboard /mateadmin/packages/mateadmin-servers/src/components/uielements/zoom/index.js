import Zoom from '@material-ui/core/Zoom';

export default Zoom;
