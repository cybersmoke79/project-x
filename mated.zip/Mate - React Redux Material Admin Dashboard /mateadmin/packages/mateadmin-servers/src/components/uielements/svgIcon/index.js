import SvgIcon from '@material-ui/core/SvgIcon';

export default SvgIcon;
