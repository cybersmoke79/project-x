import Slide from '@material-ui/core/Slide';

export default Slide;
