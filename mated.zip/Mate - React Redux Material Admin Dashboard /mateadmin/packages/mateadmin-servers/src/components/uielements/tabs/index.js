import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';

export default Tabs;
export { Tab };
