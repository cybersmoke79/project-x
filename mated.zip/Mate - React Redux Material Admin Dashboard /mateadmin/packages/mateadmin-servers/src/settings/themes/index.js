import themedefault from './themeDefault';
import theme2 from './theme2';

const themes = {
  themedefault,
  theme2
};
export default themes;
