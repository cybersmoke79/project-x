const txt = `
Componer
Sin correo seleccionado
Enviar
Botones con icono y etiquetas
Botones predeterminados
Botones de acción flotante
Botones de icono
Botones elevados
Cambiar idioma
Usos básicos
Selector personalizado
Selector de fecha y hora
Elige color
Añadir la nota
Ingrese su correo electrónico y le enviaremos un enlace de reinicio.
¿Se te olvidó tu contraseña?
Mateadmin
Ingrese una nueva contraseña y confírmela.
Salvar
Restablecer la contraseña
Mateadmin
Enviar petición
Iniciar sesión con Auth0
Registrarse
Crea una cuenta Mateadmin
Iniciar sesión con Facebook
Se te olvidó tu contraseña
Inicia sesión con Google
nombre de usuario: contraseña de demostración: demodemo o simplemente haga clic en cualquier botón.
Recuérdame
Mateadmin
¿Ya tienes una cuenta? Registrarse.
Regístrese con Auth0
Regístrate
Registrate con Facebook
Regístrese con Google
Estoy de acuerdo con los términos y condiciones
Mateadmin
VOLVER A CASA
La página que está buscando no existe o se ha movido.
Parece que te perdiste
404
VOLVER A CASA
Algo salió mal. Por favor, inténtelo de nuevo más tarde.
error de servidor interno
505
Backbone.js se convierte en una cosa
Primero underscore.js commit
Netscape 2.0 incluye la introducción de Javascript
Reaccionar es de fuente abierta; los desarrolladores se regocijan
Angular 1.0 lanzado
jQuery 1.0 lanzado
Jesse James Garrett lanza la especificación AJAX
404
505
Módulos avanzados
Buscar
Interfaz de usuario avanzada
Diálogos de alerta
Autocompletar
Avatares
Insignias
Usos Básicos
Pestañas básicas
Página en blanco
Navegaciones inferiores
Caja
Botón
Calendario
Tarjetas
Carro
Gráfico
Charla
Casillas de verificación
Revisa
Papas fritas
Progreso circular
Código espejo
Componentes
Contacto
Entradas personalizadas
Diálogos
Divisores
Paso a paso móvil - Puntos
Zona de descenso
Comercio electrónico
Email
Panel de Expansión
Realimentación
Olvidé contraseñas
Diálogos de formulario
Formik
Formularios
Frappe Chart
Diálogos de pantalla completa
Búsqueda de Github
Google Chart
Gráfico de barras
Carta de área
Gráfico de burbujas
Gráfico de velas
Combo Chart
Carta de Donut
Gráfico de gantt
Gráfico de histograma
Gráfico de linea
Gráfico de dispersión
Tabla de áreas escalonadas
Gráfico de línea de tiempo
Árbol de Carta
Gráfico de líneas de tendencia
Cuadro de caída de agua
Gráfico de árbol de palabras
Mapa de Google
Lista de cuadrícula
Cuadrícula lista con barras de título
Horizontal lineal - Etiqueta alternativa
Paso lineal lineal
Horizontal no lineal - Etiqueta alternativa
Paso lineal no lineal
Pestañas del botón del icono
Lista de cuadrícula solo de imagen
Entrada
Adornos de entrada
Entradas
Progreso interactivo
Constructor de facturas
Mapa de folletos
Progreso indeterminado lineal
Liza
Mapa
Selector de IU de material
Material Ui Tables
Menús
Mensaje
Modals
Selección múltiple
Selección nativa
Notas
Notificación
Páginas
Recogedor
Popover
Popovers
Posicionado
Información sobre herramientas posicionadas
Progreso
Paso a paso móvil - progreso
Boton de radio
Reaccionar el cuadro 2
React Color
Fechas de reacción
Reaccionar tendencia
React Vis
Re Charts
Redux Forms
Restablecer contraseñas
Diálogos de muestra
Pestañas desplazables
Selecciona
Controles de selección
tienda
Barajar
Registrarse
Regístrate
Simple Select
Sencillo
Información sobre herramientas simples
Lista de cuadrícula de una sola línea
Deslice los cuadros de diálogo de alerta
Snackbar
Paso a paso
Cambiar
Lengüeta
Mesas
Pestañas
Diseños
Entradas formateadas
Paso a paso móvil - Texto
Campos de texto
Todos
Información sobre herramientas
Transición
Ui Elements
Uppy Uploader
Stepper vertical
Widgets
Con Dialouge
Búsqueda de Youtube
Fondo
Migaja de pan
Barra lateral
Barra superior
Comprar ahora
Configuraciones
Mostrar BreadCrumb
Añadir artículo
Ascendente
Descendente
Cuadrícula
Lista
Remover el artículo
Girar
Barajar
Ayuda
Cerrar sesión
Precio total
Ver todo
Ver carro
Auto completo
Tarjeta simple
`;
export default txt;
