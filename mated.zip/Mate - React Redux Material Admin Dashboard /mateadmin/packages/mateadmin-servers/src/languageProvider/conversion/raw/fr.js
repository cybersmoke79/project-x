const txt = `
Composer
Aucun courrier sélectionné
Envoyer
Boutons avec icône et étiquettes
Boutons par défaut
Boutons d'action flottants
Boutons d'icône
Boutons surélevés
Changer de langue
Usages de base
Sélecteur personnalisé
Sélecteur de date et d'heure
Choisir la couleur
Ajouter une note
Entrez votre email et nous vous envoyons un lien de réinitialisation.
Mot de passe oublié?
Mateadmin
Entrez le nouveau mot de passe et confirmez-le.
sauvegarder
réinitialiser le mot de passe
Mateadmin
Envoyer une demande
Connectez-vous avec Auth0
Se connecter
Créer un compte Mateadmin
Se connecter avec Facebook
Mot de passe oublié
Connectez-vous avec Google
nom d'utilisateur: demo mot de passe: demodemo ou cliquez simplement sur n'importe quel bouton.
Souviens-toi de moi
Mateadmin
Vous avez déjà un compte? Se connecter.
Inscrivez-vous avec Auth0
S'inscrire
Inscrivez-vous avec Facebook
Inscrivez-vous avec Google
Je suis d'accord avec les termes et les conditions
Mateadmin
RETOUR À LA MAISON
La page que vous recherchez n'existe pas ou a été déplacée.
On dirait que tu t'es perdu
404
RETOUR À LA MAISON
Quelque chose s'est mal passé. Veuillez réessayer plus tard.
Erreur Interne du Serveur
505
Backbone.js devient une chose
Premier underscore.js commit
Netscape 2.0 embarque l'introduction de Javascript
Réagir est open-sourced; les développeurs se réjouissent
Angular 1.0 publié
Lancement de jQuery 1.0
Jesse James Garrett publie les spécifications AJAX
404
505
Modules avancés
Chercher
Interface utilisateur avancée
Dialogues d'alerte
Autocomplete
Avatars
Badges
Utilisations de base
Onglets de base
Page blanche
Bottom Navigations
Boîte
Bouton
Calendrier
Cartes
Chariot
Graphique
Bavarder
Cases à cocher
Check-out
chips
Progrès circulaire
Code miroir
Composants
Contact
Entrées personnalisées
Dialogues
Intercalaires
Mobile Stepper - Points
Zone de largage
Commerce électronique
Email
Panneau d'extension
Retour d'information
Mot de passe oublié
Form Dialogues
Formik
Formes
Tableau de Frappe
Dialogues plein écran
Github Recherche
Google Chart
Diagramme à bandes
Graphique de zone
Graphique à bulles
Graphique en chandelier
Graphique combiné
Tableau de beignets
Diagramme de Gantt
Graphique d'histogramme
Graphique en ligne
Diagramme de dispersion
Graphique de la zone en escalier
Graphique de ligne de temps
Arbre
Graphique des courbes de tendance
Carte de chute d'eau
Graphique wordTree
Google Map
Grille Liste
Liste de grille avec des barres de titre
Horizontal Linéaire - Étiquette alternative
Stepper linéaire horizontal
Horizontal non linéaire - Autre étiquette
Stepper horizontal non linéaire
Onglets de bouton d'icône
Liste de grille d'images uniquement
Contribution
Adornments d'entrée
Contributions
Progrès interactif
Générateur de factures
Carte de dépliant
Progrès linéaire indéterminé
Listes
Carte
Sélecteur d'interface utilisateur
Tables Ui
Menus
Message
Modals
Sélection multiple
Sélection native
Remarques
Notification
Pages
Cueilleur
Popover
popovers
Positionné
Infobulles positionnées
Le progrès
Mobile Stepper - progrès
Bouton radio
Réagir Graphique 2
Réagir Couleur
Réagissez les dates
Réagir à la tendance
Réagir Vis
Re Graphiques
Redux Forms
Réinitialiser les mots de passe
Exemples de dialogues
Onglets défilables
Sélectionne
Contrôles de sélection
Boutique
Shuffle
Se connecter
S'inscrire
Simple Select
Simple
Infobulles simples
Liste de grille simple ligne
Faire glisser les dialogues d'alerte
Snackbar
Stepper
Commutateur
Languette
les tables
Tabs
Layouts
Entrées formatées
Stepper mobile - Texte
Champs de texte
Todos
Info-bulles
Transition
Ui Elements
Uppy Uploader
Stepper vertical
Widgets
Avec Dialouge
Recherche Youtube
Contexte
Miette de pain
Barre latérale
Barre du haut
Acheter maintenant
Paramètres
Afficher PainCrumb
Ajouter un item
Ascendant
Descendant
la grille
liste
Retirer l'objet
Tourner
Shuffle
Aidez-moi
Connectez - Out
Prix ​​total
Voir tout
Voir le panier
Auto complet
Carte simple
`;
export default txt;
