const txt = `
Compose
No Mail Selected
Send
Buttons with icon and labels
Default Buttons
Floating Action Buttons
Icon Buttons
Raised Buttons
Change Language
Basic Usages
Custom Picker
Date and time Picker
Choose Color
Add Note
Enter your email and we send you a reset link.
Forgot Password?
Mateadmin
Enter new password and confirm it.
Save
Reset Password
Mateadmin
Send request
Login with Auth0
Sign In
Create an Mateadmin account
Login with Facebook
Forgot password
Login with Google
username: demo   password: demodemo   or just click on any button.
Remember me
Mateadmin
Already have an account? Sign in.
Sign Up with Auth0
Sign Up
Sign up with Facebook
Sign up with Google
I agree with terms and condtions
Mateadmin
BACK HOME
The page you're looking for doesn't exist or has been moved.
Looks like you got lost
404
BACK HOME
Something went wrong. Please try again later.
Internal Server Error
505
Backbone.js becomes a thing
First underscore.js commit
Netscape 2.0 ships   introducing Javascript
React is open-sourced; developers rejoice
Angular 1.0 released
jQuery 1.0 released
Jesse James Garrett releases AJAX spec
404
505
Advanced Modules
Search
Advanced UI
Alert Dialogs
Autocomplete
Avatars
Badges
Basic Uses
Basic Tabs
Blank Page
Bottom Navigations
Box
Button
Calendar
Cards
Cart
Chart
Chat
Checkboxes
Checkout
Chips
Circular Progress
Code Mirror
Components
Contact
Customized Inputs
Dialogs
Dividers
Mobile Stepper - Dots
Drop Zone
Ecommerce
Email
Expansion Panel
Feedback
Forgot Passwords
Form Dialogs
Formik
Forms
Frappe Chart
Full Screen Dialogs
Github Search
Google Chart
Bar Chart
Area Chart
Bubble Chart
Candlestick Chart
Combo Chart
Donut Chart
Gantt Chart
Histogram Chart
Line Chart
Scatter Chart
Stepped Area Chart
Time Line Chart
Tree Chart
Trend Lines Chart
Water Fall Chart
wordTree Chart
Google Map
Grid List
Grid list with titlebars
Horizontal Linear - Alternative Label
Horizontal Linear Stepper
Horizontal Non Linear - Alternative Label
Horizontal Non lLinear Stepper
Icon Button Tabs
Image-only Grid list
Input
Input Adornments
Inputs
Interactive Progress
Invoice Builder
Leaflet Map
Linear Indeterminate Progress
Lists
Map
Material UI Picker
Material Ui Tables
Menus
Message
Modals
Multiple Select
Native Select
Notes
Notification
Pages
Picker
Popover
Popovers
Positioned
Positioned Tooltips
Progress
Mobile Stepper - progress
Radio Button
React Chart 2
React Color
React Dates
React Trend
React Vis
Re Charts
Redux Forms
Reset Passwords
Sample Dialogs
Scrollable Tabs
Selects
Selection Controls
Shop
Shuffle
Sign In
Sign Up
Simple Select
Simple
Simple Tooltips
Single line Grid list
Slide Alert Dialogs
Snackbar
Stepper
Switch
Tab
Tables
Tabs
Layouts
Formatted Inputs
Mobile Stepper - Text
Text Fields
Todos
Tooltips
Transition
Ui Elements
Uppy Uploader
Vertical Stepper
Widgets
With Dialouge
Youtube Search
Background
Breadcrumb
Sidebar
Topbar
Purchase Now
Settings
Show BreadCrumb
Add Item
Ascending
Descending
Grid
List
Remove Item
Rotate
Shuffle
Help
Logout
Total Price
View All
View Cart
Auto Complete
Simple Card
`;
export default txt;
