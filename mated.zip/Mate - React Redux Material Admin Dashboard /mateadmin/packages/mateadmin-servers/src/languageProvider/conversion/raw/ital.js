const txt = `
Comporre
Nessuna posta selezionata
Inviare
Pulsanti con icone ed etichette
Pulsanti predefiniti
Pulsanti di azione fluttuanti
Pulsanti icona
Pulsanti sollevati
Cambia lingua
Usi di base
Picker personalizzato
Data e ora Picker
Scegli il colore
Aggiungi nota
Inserisci la tua email e ti invieremo un link di reset.
Ha dimenticato la password?
Mateadmin
Inserisci la nuova password e confermala.
Salvare
Resetta la password
Mateadmin
Invia richiesta
Accedi con Auth0
Registrati
Crea un account Mateadmin
Fai il login con facebook
Ha dimenticato la password
Accedi con Google
username: demo password: demodemo o fai semplicemente clic su qualsiasi pulsante.
Ricordati di me
Mateadmin
Hai già un account? Registrati.
Registrati con Auth0
Iscriviti
Iscriviti con Facebook
Registrati con Google
Sono d'accordo con termini e condoglianze
Mateadmin
RITORNO A CASA
La pagina che stai cercando non esiste o è stata spostata.
Sembra che tu ti sia perso
404
RITORNO A CASA
Qualcosa è andato storto. Per favore riprova più tardi.
Errore interno del server
505
Backbone.js diventa una cosa
Primo commit underscore.js
Netscape 2.0 include l'introduzione di Javascript
React è open-source; gli sviluppatori si rallegrano
Rilascio di Angular 1.0
jQuery 1.0 rilasciato
Jesse James Garrett rilascia spec. AJAX
404
505
Moduli avanzati
Ricerca
Interfaccia utente avanzata
Dialoghi di avviso
Completamento automatico
avatars
badge
Usi di base
Schede di base
Pagina vuota
Navigazione inferiore
Scatola
Pulsante
Calendario
Carte
Carrello
Grafico
Chiacchierare
caselle di controllo
Check-out
Patatine fritte
Progresso circolare
Codice specchio
componenti
Contatto
Ingressi personalizzati
Finestre di dialogo
divisori
Stepper mobile - Punti
Zona di rilascio
ecommerce
E-mail
Pannello di espansione
Risposta
Password dimenticate
Dialoghi modulo
FORMIK
Forme
Grafico delle Frappe
Dialoghi a schermo intero
Ricerca Github
Google Chart
Grafico a barre
Area grafico
Bubble Chart
Grafico a candela
Grafico combinato
Grafico ad anello
Diagramma di Gantt
Istogramma
Grafico a linee
Grafico a dispersione
Grafico a gradini
Grafico a linee temporali
Grafico ad albero
Grafico delle linee di tendenza
Grafico di caduta dell'acqua
wordTree Chart
Google Map
Grid List
Elenco griglia con barre del titolo
Lineare orizzontale - Etichetta alternativa
Stepper lineare orizzontale
Orizzontale non lineare - Etichetta alternativa
Stepper orizzontale non lineare
Schede del pulsante dell'icona
Elenco griglia di immagini
Ingresso
Input ornamenti
ingressi
Progressi interattivi
Costruttore di fatture
Mappa depliant
Progresso indeterminato lineare
elenchi
Carta geografica
UI Picker materiale
Tabelle Ui materiale
menu
Messaggio
Modals
Selezione multipla
Selezione nativa
Gli appunti
Notifica
pagine
Picker
popover
popovers
posizionato
Tooltips posizionati
Progresso
Mobile Stepper: progresso
Pulsante radio
Reagire Grafico 2
Reagisci colore
Date di Reazione
Reagire alla tendenza
Reagisci Vis
Re Grafici
Redux Forms
Reimposta password
Finestre di esempio
Schede scorrevoli
Seleziona
Controlli di selezione
Negozio
rimescolare
Registrati
Iscriviti
Selezione semplice
Semplice
Tooltip semplici
Elenco Griglia a riga singola
Diapositive di dialogo di avviso
Snack bar
stepper
Interruttore
linguetta
tabelle
Tabs
layout
Input formattati
Stepper mobile - Testo
Campi di testo
Todos
Tooltips
Transizione
Elementi dell'interfaccia utente
Uploader Uppy
Stepper verticale
widget
Con Dialouge
Ricerca su Youtube
sfondo
breadcrumb
Sidebar
topbar
Acquista adesso
impostazioni
Mostra BreadCrumb
Aggiungi articolo
Ascendente
Discendente
Griglia
Elenco
Rimuovi oggetto
Ruotare
rimescolare
Aiuto
Disconnettersi
Prezzo totale
Guarda tutto
Visualizza il carrello
Completamento automatico
Carta semplice
`;
export default txt;
